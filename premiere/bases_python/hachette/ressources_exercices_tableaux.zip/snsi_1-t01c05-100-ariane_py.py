
# ### 50 Le fil d’Ariane
# 
# Compléter le code dans `ariane.py` qui prend en entrée un tableau de mouvements successifs de la tortue Python `['forward(10)','right(45)'…​]` et qui renvoie un autre tableau représentant le chemin inverse, revenant au point de départ.


# Il faut :
#  - inverser tour gauche en tour droit. Les angles sont alors les mêmes et on ne change rien pour 'forward'.
#  - trouver la bonne orientation au départ (faire demi-tour de 180 degré).
# 
# Lorsque `ch` est une chaine de caractères comportant une unique parenthèse ouvrante, 
# `ch.split('(')` renvoie une liste `[before, after]` où `before` est le préfixe de la chaîne avant la parenthèse, et `after` le suffixe de la chaîne après la parenthèse.


def chemin_retour(t):
    inverses = {'forward': 'forward', 'right':'left', 'left':'right'}
    res = ['right(180)']
    for i in range(len(t)):
        # A compléter
    return res

# Test:
ch1 = ['forward(10)','right(30)','forward(15)','forward(12)','left(30)','right(20)']
ch2 = ['forward(10)','right(3)','forward(15)','left(30)','right(2)']
print(chemin_retour(ch1)) #['right(180)', 'left(20)', 'right(30)', 'forward(12)', 'forward(15)', 'left(30)', 'forward(10)']
print(chemin_retour(ch2)) #['right(180)', 'left(2)', 'right(30)', 'forward(15)', 'left(3)', 'forward(10)']
