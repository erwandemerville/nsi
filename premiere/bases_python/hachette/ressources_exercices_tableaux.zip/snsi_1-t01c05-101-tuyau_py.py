
# ### 55 Tuyau 3D
# 
# On vous donne une "matrice" $m$ à 3 dimensions représentant le parcours d’un tuyau circulant dans une masse de béton. Les cases à $1$ indiquent l’emplacement du tuyau et les cases à $0$ une position en béton.
# 
# Compléter dans le fichier `tuyau.py` une fonction calculant s’il est possible d’aller de $m[0][0][0]$ à $m[9][9][9] $ en suivant le tuyau.

# !!a) Commencer par compléter la fonction `voisins` qui renvoie la liste des cases voisines d'une case dans le bloc 3D. On pourra utiliser `append`.

def voisins(max_x,max_y,max_z,case):
    """
    Entrée: 
    - 3 entiers: la dimension sur x, y, z moins 1, c'est à dire les plus grand entiers 
    tels que m[max_x][max_y][max_z] soit définit.
    - un triplet d'entiers (ou liste de 3 entiers) x,y,z 
        tels que (0 <= x <= max_x, etc.), indiquant les coordonnées d'une case.
    Retourne: 
    la liste des voisins (bouchés ou non) de la case
    """
    x,y,z = case
    l = []
    # A compléter
    return l

# Test:
print(voisins(9,9,9,(0,1,2))==[[1, 1, 2], [0, 0, 2], [0, 2, 2], [0, 1, 1], [0, 1, 3]])
print(voisins(9,9,9,[0,0,0])==[[1, 0, 0], [0, 1, 0], [0, 0, 1]])

# !!b) Compléter la fonction suivante qui filtre les voisins pour ne renvoyer que ceux qui font partie du tuyau, donc dont la valeur est à 1.

def voisins_dans tuyau(m,case):
    """
    Entrée: une matrice 3D m à valeur dans 0 et 1. Une case (triplet de coordonnées) dans cette matrice.
    Retourne la liste des voisins de la case qui font partie du tuyau.
    """
    return # A compléter

# !!c) Compléter la fonction suivante, qui répond au problème.
# 
# Pour faciliter un peu le problème on va supposer qu'il n'y a pas d'embranchements, ce qui signifie plus précisément : 
# 
# - chaque case a au maximum deux cases voisines à 1
# 
# - la case m[0][0][0] a au maximum une case voisine à 1
# 
# - on ne se déplace pas en diagonale: une case m[i][j][k] a au maximum 6 cases voisines :
# m[i+1][j][k], m[i-1][j][k], m[i][j+1][k]...
# 
# NOTE : le problème avec embranchement est un problème d'exploration de graphe plus compliqué, et sera vu en terminale (en gros, pour chaque nouveau voisin il faut vérifier si on ne l'a pas déjà visité).
# 
# Indice : Lorsque l'on arrive sur une case qui a deux voisins, il faut éviter de sélectionner celui dont on vient. On pourra utiliser t.append() pour construire le tableau contenant le chemin, et t[-1] pour sélectionner la dernière étape du chemin parcouru.


def cherche_chemin(m, origin=[0,0,0], destination=[9,9,9]):
    """Retourne le chemin d'origin à destination, et [] s'il n'y en a pas.
    
    A tout instant la case courante a au plus 2 voisins dont 1 est le précédent, donc jamais plus d'une nouvelle case
    On pourrait distinguer avec des conditions :
    - les cas où il y a 1 ou 2 voisins,
    - les cas où le voisins précédent apparait en position 0 ou 1.
    Mais il est ici un peu plus simple de filtrer par compréhension
    """
    if voisins_libres(m,origin) == []:
        return 'Pas de chemin'
    else:
        chemin = [origin]
        # A compléter (Titan)

# Test:
def gener_cube(n = 10):
    return [[[0]*n for j in range(n)] for i in range(n)]

a = gener_cube()
for c in [[0,0,0],[0,0,1],[0,0,2],[0,1,2],[0,1,3],[0,2,3],[0,3,3],[0,4,3],[0,4,2],[1,4,2],[1,5,2],[2,5,2],[3,5,2],[3,4,2],[4,4,2],[5,4,2],[6,4,2],[7,4,2],[7,4,3],[7,4,4],[8,4,4],[8,5,4],[9,5,4],[9,5,5],[9,5,6],[9,5,7],[9,5,8],[9,5,9],[9,6,9],[9,7,9],[9,8,9],[9,9,9]]:
     a[c[0]][c[1]][c[2]]=1
print(cherche_chemin(a) == [[0,0,0],[0,0,1],[0,0,2],[0,1,2],[0,1,3],[0,2,3],[0,3,3],[0,4,3],[0,4,2],[1,4,2],[1,5,2],[2,5,2],[3,5,2],[3,4,2],[4,4,2],[5,4,2],[6,4,2],[7,4,2],[7,4,3],[7,4,4],[8,4,4],[8,5,4],[9,5,4],[9,5,5],[9,5,6],[9,5,7],[9,5,8],[9,5,9],[9,6,9],[9,7,9]])
