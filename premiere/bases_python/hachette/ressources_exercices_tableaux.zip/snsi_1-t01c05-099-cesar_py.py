
# ### 39 Le chiffre de César
# 
# Compléter le fichier `cesar.py` pour coder un texte en utilisant le chiffrement de César.

# Noter qu'on se contentera de coder un texte en minuscule sans espace ou ponctuation (donc le texte en entrée doit être une chaine de caractères ne contenant que des minuscules. Il ne serait pas très difficile d'étendre la fonction d'encodage/décodage pour qu'elles décalent aussi les majuscules et préservent les autres symboles (les espaces et signes de ponctuation), mais cela rendrait le code plus compliqué.

import string
# Solution naive : on construit un tableau de toutes les lettres minuscules (dans l'ordre) avec string.ascii_lowercase
def rang_naif(lettre):
    """
    Entrée: un caractère minuscule
    Renvoie: le rang de la lettre: 0 pour 'a', 25 pour 'z'...
    Utilise string.ascii_lowercase.
    """
    for i, x in enumerate(string.ascii_lowercase):
        if x == lettre:
            return i

        
def encode_naif(texte, decalage):
    """
    Entrée: un texte en clair, la valeur du décalage
    Renvoie: le même texte encodé avec le code de césar; chaque lettre est 'décalée' du décalage vers la droite,
    de manière cyclique; après le 'z' on revient à 'a'.
    Utilise string.ascii_lowercase.
    """
    t = string.ascii_lowercase
    # A compléter

def decode_naif(texte, decalage):
    """
    Entrée: un texte chiffré, la valeur du décalage
    Renvoie: le même texte encodé avec le code de césar; chaque lettre est 'décalée' du décalage vers la droite,
    de manière cyclique; après le 'z' on revient à 'a'.
    Utilise string.ascii_lowercase.
    """
    t = string.ascii_lowercase
    # A compléter

# Test:
print(rang_naif('a')==0)
print(encode_naif('letempsestpluvieux',1)=='mfufnqtftuqmvwjfvy')
print(decode_naif('mfufnqtftuqmvwjfvy',1)=='letempsestpluvieux')

# Une solution plus intelligente : 
# La fonction Python: chr(i) 
#    renvoie la chaîne représentant un caractère dont le code de caractère Unicode est le nombre entier i.
# chr(97) == 'a'
# chr(122)== 'z'
# La fonction Python: ord(i) 
#    prend une chaîne Unicode d'un caractère et renvoie la valeur du point de code.
# La fonction ord est donc l'inverse de chr.

def rang(lettre):
    """
    Entrée: un caractère minuscule
    Renvoie: le rang de la lettre: 0 pour 'a', 25 pour 'z'...
    Utilise ord ou chr (on ne vous indique pas lequel).
    """
    return # A compléter


def encode(texte, decalage):
    """
    Entrée: un texte en clair, la valeur du décalage
    Renvoie: le même texte encodé avec le code de césar; chaque lettre est 'décalée' du décalage vers la droite,
    de manière cyclique; après le 'z' on revient à 'a'.
    Utilise chr et ord.
    """
    # A compléter


def decode(texte, decalage):
    """
    Entrée: un texte chiffré, la valeur du décalage
    Renvoie: le même texte encodé avec le code de césar; chaque lettre est 'décalée' du décalage vers la droite,
    de manière cyclique; après le 'z' on revient à 'a'.
    Utilise chr et ord.
    """
    # A compléter


# Test:
print(rang('a')==0)
print(rang('z')==25)
print(encode('letempsestpluvieux',1)=='mfufnqtftuqmvwjfvy')
print(decode('mfufnqtftuqmvwjfvy',1)=='letempsestpluvieux')

# !!b) Est-il en fait nécessaire de définir explicitement une fonction pour le décodage? Pourquoi?
