#
# Chapitre 3 - Exercice 29 (p69) - Importation croisée de modules
#

from m1 import f11

def f2():
	print(' f2')
	f11()

def f22():
	print(' f22')
