#
# Chapitre 3 - Exercice 29 (p69) - Importation croisée de modules
#

from m1 import f1

f1()
