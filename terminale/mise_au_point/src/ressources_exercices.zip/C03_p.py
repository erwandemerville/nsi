#
# Chapitre 3 - Exercice 28 (p69) - Masquage de noms importés
#

from m import f, g

f()

def h():
	print('h appelle g')
	g()

h()

print('redéfinition de g')

def g():
	print(' g redéfini')

f()
h()
