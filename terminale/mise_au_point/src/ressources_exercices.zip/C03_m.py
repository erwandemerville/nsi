#
# Chapitre 3 - Exercice 28 (p69) - Masquage de noms importés
#

def g():
    print('  g')

def f():
    print('f appelle g')
    g()
