#
# Chapitre 3 - Exercice 24 - Recherche de chaîne
#
# Code a tester et corriger si besoin
#
def derniere_sous_chaine(s, ch):
    trouve = -1
    for debut in range(len(ch)):
        i = 0
        while i < len(s) and s[i] == ch[debut+i]:
            i += 1
            if i == len(s):
                trouve = debut
    return trouve
