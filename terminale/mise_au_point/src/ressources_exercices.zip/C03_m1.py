#
# Chapitre 3 - Exercice 29 (p69) - Importation croisée de modules
#

from m2 import f22

def f1():
	print(' f1')
	f22()

def f11():
	print(' f11')
