#
# Chapitre 3 - Exercice Titan 27 - Modulariser un programme
#

import csv

# Notes :
# Le fichier covid.csv est obtenu à partir des données disponibles ici :
#   https://data.europa.eu/data/datasets/60190d00a7273a8100dd4d38?locale=fr
# en supprimant les lignes incomplètes et les colonnes inutiles
# 
# Le fichier demographie.csv est obtenu à partir des données disponibles ici :
#   https://www.gapminder.org/data/documentation/gd003/
# en utilisant les données du dernier onglet, lignes 202 à 207

# Lire le fichier CSV et extraire les données
donnees = {
    'positifs': [],
    'hospitalisations': [],
    'reanimation': [],
    'deces': [],
}
with open('covid.csv') as csvfile:
    for ligne in csv.DictReader(csvfile, delimiter=';'):
        donnees['positifs'].append(int(ligne['pos']))
        donnees['hospitalisations'].append(int(ligne['incid_hosp']))
        donnees['reanimation'].append(int(ligne['incid_rea']))
        donnees['deces'].append(int(ligne['incid_dchosp']))

# Calculer les moyennes par semaine et les totaux
moyennes = {
    'positifs': [],
    'hospitalisations': [],
    'reanimation': [],
    'deces': [],
}
totaux = {
    'positifs': 0,
    'hospitalisations': 0,
    'reanimation': 0,
    'deces': 0,
}
for colonne in donnees.keys():
    semaine = 0
    for i in range(len(donnees[colonne])):
        valeur = donnees[colonne][i]
        totaux[colonne] += valeur
        semaine += valeur
        if i % 7 == 6:
            moyennes[colonne].append(semaine / 7)
            semaine = 0

# Afficher les graphes et les totaux
from matplotlib.pyplot import plot, show, legend

print('Total positifs         :', totaux['positifs'])
print('Total hospitalisations :', totaux['hospitalisations'])
print('Total reanimation      :', totaux['reanimation'])
print('Total deces            :', totaux['deces'])

# Si on affiche ce graphe avec les autres, ils ne sont pas visibles
plot(moyennes['positifs']) 
legend(['positifs'])
show()

plot(moyennes['hospitalisations'])
plot(moyennes['reanimation'])
plot(moyennes['deces'])
legend(['hospitalisations', 'reanimation', 'deces'])
show()
