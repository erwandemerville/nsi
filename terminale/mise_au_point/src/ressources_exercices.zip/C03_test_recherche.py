#
# Chapitre 3 - Exercice 24 - Recherche de chaîne
#
# Tests à exécuter avec pytest
#
import pytest

### Fonction à compléter
def sous_chaine(partie, tout):
    """ Retourne l'indice de la première occurrence de la chaîne `partie`
        dans la chaîne `tout`, ou -1 s'il n'y a pas de telle occurrent """
    ### COMPLÉTER le code ici
    return -1
###

def test_type1():
    with pytest.raises(AssertionError):
        sous_chaine('1', 123)

def test_type2():
    with pytest.raises(AssertionError):
        sous_chaine(1, '123')

def test_debut():
    assert sous_chaine('debut', 'debut de chaine') == 0

def test_milieu():
    assert sous_chaine(' de ', 'milieu de chaine') == 6

def test_fin():
    assert sous_chaine('chaine', 'fin de chaine') == 7

def test_partiel1():
    assert sous_chaine('debut', 'de deb debu debut fin') == 12

def test_partiel2():
    assert sous_chaine('debut', 'de deb debu') == -1

def test_repetition():
    assert sous_chaine('tata', 'taratataratata') == 4

def test_vide1():
    assert sous_chaine('', 'hello') == 0

def test_vide2():
    assert sous_chaine('', '') == 0

