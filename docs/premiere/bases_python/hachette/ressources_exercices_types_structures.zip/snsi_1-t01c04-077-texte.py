#
# Exercice 30 - Analyse de texte
#

# On dispose de la suite des mots d’une texte dans un tableau de 
# chaînes de caractères. On souhaite compter le nombre de fois 
# que chaque mot apparait dans le texte.

texte = """
Si tu peux voir détruit l’ouvrage de ta vie 
Et sans dire un seul mot te mettre à rebâtir, 
Ou perdre en un seul coup le gain de cent parties 
Sans un geste et sans un soupir ;

Si tu peux être amant sans être fou d’amour, 
Si tu peux être fort sans cesser d’être tendre, 
Et, te sentant haï, sans haïr à ton tour, 
Pourtant lutter et te défendre ;

Si tu peux supporter d’entendre tes paroles 
Travesties par des gueux pour exciter des sots, 
Et d’entendre mentir sur toi leurs bouches folles 
Sans mentir toi-même d’un mot ;

Si tu peux rester digne en étant populaire, 
Si tu peux rester peuple en conseillant les rois, 
Et si tu peux aimer tous tes amis en frère, 
Sans qu’aucun d’eux soit tout pour toi ;

Si tu sais méditer, observer et connaître, 
Sans jamais devenir sceptique ou destructeur, 
Rêver, mais sans laisser ton rêve être ton maître, 
Penser sans n’être qu’un penseur ;

Si tu peux être dur sans jamais être en rage, 
Si tu peux être brave et jamais imprudent, 
Si tu sais être bon, si tu sais être sage, 
Sans être moral ni pédant ;

Si tu peux rencontrer Triomphe après Défaite 
Et recevoir ces deux menteurs d’un même front, 
Si tu peux conserver ton courage et ta tête 
Quand tous les autres les perdront,

Alors les Rois, les Dieux, la Chance et la Victoire 
Seront à tous jamais tes esclaves soumis, 
Et, ce qui vaut mieux que les Rois et la Gloire 
Tu seras un homme, mon fils.
"""
# 			Rudyard Kipling

# créer le tableau de mots à partir du texte ci-dessus
import re
mots = re.split(r'\W+', texte)

# pour créer un tableau de mots à partir du fichier texte.txt :
# fichier = open("texte.txt", "r")
# mots = re.split(r'\W+', fichier.read())

# a) Définir un type construit permettant de compter facilement 
# le nombre d’occurrences de chaque mot. 


# b) Écrire une fonction qui prend en paramètre un tableau de mots et retourne 
# une valeur de ce type. On pourra utiliser la méthode `lower()` des chaînes 
# de caractères pour transformer les majuscules en minuscules.


# c) Écrire un programme qui lit un texte et affiche les mots qui apparaissent 
# une seule fois dans le texte.

