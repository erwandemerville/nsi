# Interface fonctionnelle du type abstrait Lsite
def creer_liste():
    return ()

def tete(liste):
    return liste[0]

def queue(liste):
    return liste[1]

def inserer(element, liste):
    return (element, liste)

def est_vide(liste):
    return liste == ()

def taille_liste(liste):
    if est_vide(liste):
        return 0
    return 1 + taille_liste(queue(liste))
