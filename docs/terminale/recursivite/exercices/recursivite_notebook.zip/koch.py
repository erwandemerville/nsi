from turtle import *

def koch(n,l):
    '''dessine un flocon de koch
    de profondeur n, a partir d'un 
    segment de longueur l'''
    if n == 0 :
        forward(l)
    else :
        koch(n-1,l//3)
        left(60)
        koch(n-1,l//3)
        right(120)
        koch(n-1,l//3)
        left(60)
        koch(n-1,l//3)
        
        



koch(5,600)    
mainloop()