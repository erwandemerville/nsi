#!/usr/bin/python3
# -*- coding: utf-8 -*-

import random  # Module random pour générer des valeurs aléatoires (avec random.choice)


class PokemonError(Exception):
    ''' Classe permettant de générer des messages d'erreur.
    Par exemple : PokemonError("ERREUR !") '''

    def __init__(self, msg):
        self.message = msg


class Pokemon:
    ''' Classe Pokemon.
    Ses attributs sont :
    - Son nom : Chaîne de caractères
    - Son ou ses types : Tableau de chaînes de caractères (Exemple : ['Feu'] ou ['Normal', 'Air']
    - Son nombre de points de vies : Entier
    - Son attaque : Entier
    - Sa défense : Entier
    - Son état : Tuple de deux valeurs, exemple : ('normal', 0) ou ('paralysie', 3)
    - Liste de ses attaques sous forme d'un tableau, par exemple : [['Charge', 50], ['Eclaire', 'paralysie', 5]]'''

    def __init__(self, nom, types, pts_vies, attaque, defense, liste_attaques):
        ''' CONSTRUCTEUR A COMPLETER '''
        self._nom = .......
        self._types = .......
        self._pts_vies = .......
        self._attaque = .......
        self._defense = .......
        self._liste_attaques = .......
        self._etat = {"nom_etat": 'normal', "duree_etat": -1}  # État initial (normal), durée -1 = infinie

    # DEFINITION DES GETTERS :
    # Ce sont les fonctions qui permettent de RECUPERER les valeurs des attributs du pokémon.

    def get_nom(self):
        ''' A COMPLETER - Renvoie la valeur de l'attribut _nom '''
        ........

    def get_vies(self):
        ''' A COMPLETER - Renvoie la valeur de l'attribut _pts_vies '''
        ........

    def get_attaque(self):
        ''' A COMPLETER - Renvoie la valeur de l'attribut _attaque '''
        ........

    def get_defense(self):
        ''' A COMPLETER - Renvoie la valeur de l'attribut _defense '''
        ........

    def get_etat(self):
        ''' A COMPLETER - Renvoie la valeur de l'attribut _etat '''
        ........

    # DEFINITION DES SETTERS :
    # Ce sont les fonctions qui permettent de MODIFIER les valeurs des attributs du pokémon.

    def set_etat(self, n_etat):
        ''' A COMPLETER : Modifie la valeur de l'attribut _etat '''
        ..........
        
    def set_vies(self, n_vies):
        ''' A COMPLETER : Modifie la valeur de l'attribut _pts_vies '''
        ..........
    
    def set_attaque(self, n_attaque):
        ''' A COMPLETER : Modifie la valeur de l'attribut _attaque '''
        ..........

    def set_defense(self, n_defense):
        ''' A COMPLETER : Modifie la valeur de l'attribut _defense '''
        ..........

    def baisser_vies(self, nb):
        ''' COMPLETER - Fonction qui retire "nb" points de vies au nombre de vies du pokémon.
        Deux possibilités :
        - Si le nouveau nombre de pts de vies est inférieur à 0, on met le nombre de points de vies à 0
        - Sinon, le nouveau nombre de pts de vies est la soustraction de l'ancien nombre de pts de vies et de "nb".
        :param nb: (int) Le nombre de points de vies à retirer. '''

        ...........

    def baisser_attaque(self, nb):
        ''' COMPLETER - Même principe que baisser_vies() mais pour l'attaque. '''
        ...........

    def baisser_defense(self, nb):
        ''' COMPLETER - Même principe que baisser_vies() mais pour la défense. '''
        ...........

    def augmenter_vies(self, nb):
        ''' COMPLETER - Fonction qui ajoute "nb" vies au nombre de vies actuel du Pokémon. '''
        ............

    def augmenter_attaque(self, nb):
        ''' COMPLETER - Fonction qui ajoute nb à l'attaque du pokémon. '''
        ............

    def augmenter_defense(self, nb):
        ''' COMPLETER - Fonction qui ajoute nb à la défense du pokémon. '''
        ............

    # AUTRES METHODES UTILES

    def est_mort(self):
        ''' Renvoie True si le Pokémon est mort (points de vies à 0), False sinon. '''
        ............

    # METHODES RELATIVES AUX ATTAQUES

    def choix_attaque_aleatoire(self):
        ''' Renvoie les données d'une attaque choisie aléatoirement.
        COMPLETER LES POINTILLES - On souhaite renvoyer un élément de _liste_attaques aléatoire).
        '''

        attaque = random.choice(......................)
        return attaque

    def choix_attaque(self):
        ''' Fonction qui affiche la liste des attaques ainsi que leurs caractéristiques,
        puis renvoie les informations sur l'attaque choisie par le joueur (= un dictionnaire de _liste_attaques).
        COMPLETER LES POINTILLES SUR LA DERNIERE LIGNE '''

        i = 1
        for el in self._liste_attaques:  # Pour chaque liste de _liste_attaques (donc pour chaque attaque)
            print(f"{i} - {el['nom_attaque']} : ", end='')  # On affiche un numéro puis le nom de l'attaque
            if len(el) == 3:  # 3 éléments, cela signifie qu'il s'agit d'une attaque spécial (poison, paralysie, etc.)
                if el["nom_effet"] == 'attaque-e':
                    print(f"Diminue de {el['valeur_effet']} l'attaque du pokémon ennemi")
                elif el["nom_effet"] == 'defense-e':
                    print(f"Diminue de {el['valeur_effet']} la défense du pokémon ennemi")
                elif el["nom_effet"] == 'attaque+':
                    print(f"Augmente de {el['valeur_effet']} l'attaque du pokémon allié")
                elif el["nom_effet"] == 'defense+':
                    print(f"Augmente de {el['valeur_effet']} la défense du pokémon allié")
                elif el["nom_effet"] == 'poison':
                    print(f"Empoisonne votre adversaire pour {el['valeur_effet']} tours.")
                elif el["nom_effet"] == 'drainage':
                    print(f"Draine l'énergie de votre adversaire pour {el['valeur_effet']} tours.")
                elif el["nom_effet"] == 'paralysie':
                    print(f"Paralyse votre adversaire pour {el['valeur_effet']} tours.")
                else:
                    PokemonError(f"ERREUR : Type d'attaque {el['nom_effet']} inconnu !")
            else:  # Sinon (2 éléments), il s'agit d'une attaque normale.
                print(f"Puissance de l'attaque : {el['degats_attaque']}")

            i += 1

        choix = input("Quelle attaque choisissez-vous ? ")
        return self._liste_attaques[............]
