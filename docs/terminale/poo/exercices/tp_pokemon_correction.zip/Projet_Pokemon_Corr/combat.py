#!/usr/bin/python3
# -*- coding: utf-8 -*-

from time import sleep

# ======================== VARIABLES GLOBALES =====================================
DEGATS_POISON = 5  # Nombre de PV perdus à chaque tout à cause du poison
DEGATS_DRAINAGE = 5  # Nombre de PV perdus à chaque tout à cause du drainage
# =================================================================================


class CombatError(Exception):
    ''' Classe permettant de générer des messages d'erreur.
    Par exemple : CombatError("ERREUR !") '''
    def __init__(self, msg):
        self.message = msg


class Combat:
    ''' Classe Pokemon.
    Ses attributs sont :
    - Le pokémon du joueur : Un objet de classe Pokemon
    - Le pokémon adversaire : Un objet de classe Pokemon
    - Le numéro du tour _ntour '''

    def __init__(self, pokemon_joueur, pokemon_ennemi):
        ''' COMPLETER CE CONSTRUCTEUR + AJOUTER L'ATTRIBUT _ntour ET L'INITIALISER A 1 '''
        self._pokemon_joueur = pokemon_joueur
        self._pokemon_ennemi = pokemon_ennemi
        self._ntour = 1  # Numéro du tour


    def get_pokemon_joueur(self):
        ''' A COMPLETER - Renvoie le pokémon du joueur '''
        return self._pokemon_joueur

    def get_pokemon_ennemi(self):
        ''' A COMPLETER - Renvoie le pokémon de l'adversaire '''
        return self._pokemon_ennemi

    def get_numero_tour(self):
        ''' A COMPLETER - Renvoie le numéro du tour actuel '''
        return self._ntour

    def augmenter_tour(self):
        ''' A COMPLETER - Augmenter de 1 le numéro du tour '''
        self._ntour += 1

    def afficher_etat(self):
        ''' Afficher l'état des pokémons (leur nombre de points de vies restants, l'état (normal, poison, etc.))
        COMPLETER LES POINTILLES '''
        joueur = self.get_pokemon_joueur()
        ennemi = self.get_pokemon_ennemi()
        print("---------------------------------")
        print(f"{joueur.get_nom()} : {joueur.get_vies()} PV restants. \
        Etat : {joueur.get_etat()['nom_etat']}. Attaque/Défense : {joueur.get_attaque()}/{joueur.get_defense()}")
        print(f"{ennemi.get_nom()} : {ennemi.get_vies()} PV restants. \
        Etat : {ennemi.get_etat()['nom_etat']}. Attaque/Défense : {ennemi.get_attaque()}/{ennemi.get_defense()}")
        print("---------------------------------")

    def activation_effets(self):
        ''' Cette fonction vérifie s'il y a eu des altérations d'état sur les pokémons (comme la paralysie, le poison.)
        - S'ils ne sont pas dans leur état normal (empoisonnés, brulés, etc.), activer les effets en conséquence.
        - Diminuer d'un tour la durée restante pour l'état du pokémon.
        ==> A COMPLETER <== '''

        pokemons = [self.get_pokemon_joueur(), self.get_pokemon_ennemi()]  # On met les deux pokémons dans une liste
        for i in range(len(pokemons)):  # Pour chacun des deux pokémons
            pokemon = pokemons[i]  # On récupère le pokémon pour lequel on souhaite activer les effets
            if pokemon.get_etat()["nom_etat"] != 'normal':  # On vérifie si l'état du pokémon est "normal"
                if pokemon.get_etat()["nom_etat"] == 'poison':  # On vérifie si le pokémon est empoisonné
                    print(f"{pokemon.get_nom()} souffre du poison et perd {DEGATS_POISON} PV...")
                    pokemon.baisser_vies(DEGATS_POISON)
                if pokemon.get_etat()["nom_etat"] == 'drainage':  # On vérifie si l'énergie du pokémon est drainées
                    lanceur = pokemons[(i + 1) % 2]  # On récupère le pokémon ayant lancé le drainage
                    print(f"L'énergie de {pokemon.get_nom()} est drainée. {lanceur.get_nom()} aspire {DEGATS_DRAINAGE} PV...")
                    pokemon.baisser_vies(DEGATS_DRAINAGE)
                    lanceur.augmenter_vies(DEGATS_DRAINAGE)
                if pokemon.get_etat()["nom_etat"] == 'paralysie':  # On vérifie si le pokémon est paralysé
                    print(f"{pokemon.get_nom()} est paralysé. Il ne peut pas attaquer.")

                duree_restante_etat = pokemon.get_etat()["duree_etat"] - 1
                if duree_restante_etat == 0:
                    pokemon.set_etat({"nom_etat": 'normal', "duree_etat": '-1'})
                else:
                    pokemon.set_etat({"nom_etat": pokemon.get_etat()["nom_etat"], "duree_etat": duree_restante_etat})

    def attaquer(self, attaque, attaquant, cible):
        ''' Lance une attaque sur le pokémon cible.
        :param attaque: (dict) Informations sur l'attaque sous forme d'un dictionnaire.
        :param attaquant: (Pokemon) Le pokémon attaquant.
        :param cible: (Pokemon) Pokemon visé par l'attaque.

        On rappelle qu'une attaque peut peut être de la forme :
        {"nom_attaque": "Charge", "degats_attaque": 35} ou
        {"nom_attaque": "Rugissement", "effet_attaque": "attaque-e", "valeur_attaque": 5} pour les attaques à effets.'''

        nom_attaque = attaque["nom_attaque"]
        print(f"{attaquant.get_nom()} ATTAQUE {nom_attaque} !!")
        if len(attaque) == 3:  # Si attaque à effets
            effet_attaque = attaque["nom_effet"]
            valeur_effet = attaque["valeur_effet"]
            if effet_attaque == 'attaque-e':
                cible.baisser_attaque(valeur_effet)
                print(f"L'attaque de {cible.get_nom()} diminue.")
            elif effet_attaque == 'defense-e':
                cible.baisser_defense(valeur_effet)
                print(f"La défense de {cible.get_nom()} diminue.")
            elif effet_attaque == 'attaque+':
                attaquant.augmenter_attaque(valeur_effet)
                print(f"L'attaque' de {attaquant.get_nom()} augmente.")
            elif effet_attaque == 'defense+':
                attaquant.augmenter_defense(valeur_effet)
                print(f"La défense de {attaquant.get_nom()} augmente.")
            elif effet_attaque == 'poison':
                cible.set_etat({"nom_etat": 'poison', "duree_etat": valeur_effet})
                print(f"{cible.get_nom()} est empoisonné pendant {valeur_effet} tours !")
            elif effet_attaque == 'drainage':
                cible.set_etat({"nom_etat": 'drainage', "duree_etat": valeur_effet})
                print(f"L'énergie de {cible.get_nom()} est drainée pendant {valeur_effet} tours !")
            elif effet_attaque == 'paralysie':
                cible.set_etat({"nom_etat": 'paralysie', "duree_etat": valeur_effet})
                print(f"{cible.get_nom()} est paralysé pendant {valeur_effet} tours ! Il ne peut plus attaquer.")
            else:
                CombatError(f"ERREUR : Type d'attaque {effet_attaque} inconnu !")
        else:  # Si attaque classique (2 éléments dans le dictionnaire attaque)
            puissance_attaque = attaque["degats_attaque"]
            # Les deux lignes suivantes calculent les dégâts infligés par l'attaque en fonction
            # de la puissance de l'attaque, de l'attaque du pokémon attaquant et de la défense du pokémon ciblé.
            # Vous pouvez changer ce calcul si souhaitez changer la manière dont les dégâts sont déterminés
            degats_infliges = (puissance_attaque * attaquant.get_attaque()) / (cible.get_defense() * 2.4 + 1)
            degats_infliges = round(degats_infliges)  # Arrondir à l'entier le plus proche

            cible.baisser_vies(degats_infliges)
            print(f"{cible.get_nom()} perd {degats_infliges} PV !")

    def message_victoire(self):
        ''' Affiche un message en cas de victoire '''
        print(f"Félicitations ! {self.get_pokemon_ennemi().get_nom()} est K.O.")

    def message_defaite(self):
        ''' A COMPLETER '''
        print(f"{self.get_pokemon_joueur().get_nom()} est K.O. Quel dommage !")

    def jouer(self):
        ''' FONCTION QUI GERE LE DEROULEMENT DES TOURS.
        La fonction continue de tourner de manière infinie, jusqu'à ce qu'il y ait un gagnant.
        COMPLETER LA FONCTION '''
        tour = 0  # On définit variable locale 'tour' qui vaut 0 si c'est le tour du joueur, 1 si c'est celui de l'ennemi
        while True:  # Boucle infinie
            print()
            if self.get_pokemon_joueur().est_mort(): # SI LE POKEMON DU JOUEUR EST MORT (compléter)
                self.message_defaite()
                return False  # On renvoie False pour indiquer une défaite
            elif self.get_pokemon_ennemi().est_mort(): # SI LE POKEMON ENNEMI EST MORT (compléter)
                self.message_victoire()
                return True  # On renvoie True pour indiquer une victoire
            else:
                self.afficher_etat()  # Affichage de l'état des pokémons
                sleep(2)  # Laisser un délai de 2 secondes
                print()
                self.activation_effets()  # Activation des altérations d'états
                print(f"TOUR {self.get_numero_tour()}")  # Affichage du numéro du tour
                if tour == 0:
                    if not self.get_pokemon_joueur().get_etat()["nom_etat"] == 'paralysie':
                        print(f"C'est à {self.get_pokemon_joueur().get_nom()} de jouer !")
                        attaque = self.get_pokemon_joueur().choix_attaque()
                        self.attaquer(attaque, self.get_pokemon_joueur(), self.get_pokemon_ennemi())
                        sleep(3)  # Laisser un délai de 3 secondes
                    tour = 1
                else:  # C'est le tour du pokémon adversaire
                    if not self.get_pokemon_ennemi().get_etat()["nom_etat"] == 'paralysie':
                        print(f"C'est à {self.get_pokemon_ennemi().get_nom()} de jouer.")
                        sleep(3)
                        attaque = self.get_pokemon_ennemi().choix_attaque_aleatoire()
                        self.attaquer(attaque, self.get_pokemon_ennemi(), self.get_pokemon_joueur())
                        sleep(3)
                    tour = 0
                self.augmenter_tour()  # Incrémenter le nombre de tours